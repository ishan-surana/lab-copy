#include <stdio.h>
#include <unistd.h>
int main() {
printf("Done in execl");
execl("/bin/ls", "ls", "-l", NULL);
perror("execl");
return 1;
}
