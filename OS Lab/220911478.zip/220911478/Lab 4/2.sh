for i in $*; do
    rm -i $i
done