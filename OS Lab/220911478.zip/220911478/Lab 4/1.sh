file=$1
cp $file $file".copy"
echo "File copied to $file.copy"