echo $1
echo $2
echo $#
echo $BASH
echo $OSTYPE
var1='I am global'
function f(){
local var2='I am local'
echo $var2
}
f
echo $var2
echo $var1
