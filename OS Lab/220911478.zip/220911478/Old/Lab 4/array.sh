j=0
for i in $@
do
arr[j]=$i
echo "J =" $j
((j++))
done
echo "Array =" ${arr[@]}