for file in *; do
    if [ -f "$file" ]; then
        sed -i -E '
            /^[ \t]*ex:/s/^([ \t]*)ex:/\1example:/
            s/\.(\s*)ex:/.\1example:/g
        ' "$file"
    fi
done