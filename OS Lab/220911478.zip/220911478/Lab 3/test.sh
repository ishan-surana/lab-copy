read a b
if (($a==$b));then # if [ $a == $b ];
echo "True"
else
echo "False"
fi
