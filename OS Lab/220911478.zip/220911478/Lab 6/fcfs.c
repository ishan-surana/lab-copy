// #include <stdio.h>
// #include <stdlib.h>
// int main()
// {
//     int n;
//     printf("Input number of processes:- ");
//     scanf("%d", &n);
//     int processes[3][n];
//     getchar();
//     printf("Enter process numbers:- ");
//     for(int i=0;i<n;i++) scanf("%d", &processes[0][i]);
//     printf("Enter process arrival times:- ");
//     for(int i=0;i<n;i++) scanf("%d", &processes[1][i]);
//     printf("Enter process burst times:- ");
//     for(int i=0;i<n;i++) scanf("%d", &processes[2][i]);
//     for(int i=0;i<3;i++)
//     {
//         for(int j=0;j<n;j++)
//         printf("%d ", processes[i][j]);
//         printf("\n");
//     }
//     printf("\n");
//     for(int i=0;i<n-1;i++)
//     for(int j=i+1;j<n;j++)
//     if(processes[1][j]<processes[1][i])
//     for(int k=0;k<3;k++)
//     {
//         int temp = processes[k][i];
//         processes[k][i] = processes[k][j];
//         processes[k][j] = temp;
//     }
//     for(int i=0;i<3;i++)
//     {
//         for(int j=0;j<n;j++)
//         printf("%d ", processes[i][j]);
//         printf("\n");
//     }
//     return 0;
// }

/*
Input number of processes:- 5
Enter process numbers:- 1 2 3 4 5
Enter process arrival times:- 3 5 1 2 4
Enter process burst times:- 5 2 4 1 3
*/

#include <stdio.h>
#include <stdlib.h>
int main()
{
    int n;
    printf("Input number of processes: ");
    scanf("%d", &n);
    int processes[7][n];
    getchar();
    printf("Enter process numbers: ");
    for(int i=0;i<n;i++) scanf("%d", &processes[0][i]);
    printf("Enter process arrival times: ");
    for(int i=0;i<n;i++) scanf("%d", &processes[1][i]);
    printf("Enter process burst times: ");
    for(int i=0;i<n;i++) scanf("%d", &processes[2][i]);
    // print input
    printf("\nInput Data:\n");
    for(int i=0;i<3;i++)
    {
        for(int j=0;j<n;j++)
        printf("%d ", processes[i][j]);
        printf("\n");
    }
    // bubble sort for fcfs
    for(int i=0;i<n-1;i++)
        for(int j=i+1;j<n;j++)
            if(processes[1][j]<processes[1][i])
                for(int k=0; k<6;k++)
                {
                    int temp = processes[k][i];
                    processes[k][i]=processes[k][j];
                    processes[k][j]=temp;
                }
    int currentTime = 0;
    for(int i=0;i<n;i++)
    {
        if(currentTime<processes[1][i])
            currentTime=processes[1][i];
        processes[3][i]=currentTime; // Start Time
        processes[4][i]=processes[3][i]+processes[2][i]; // Finish Time
        processes[5][i]=processes[3][i]-processes[1][i]; // Waiting Time
        processes[6][i]=processes[4][i]-processes[1][i]; // Turnaround Time
        currentTime=processes[4][i];
    }
    printf("\nFCFS Scheduling Results:\n");
    printf("%-8s %-12s %-10s %-10s %-12s %-15s %-10s\n",
           "Process", "Arrival Time", "Burst Time", "Start Time", "Finish Time", "Waiting Time", "Turnaround Time");
    printf("=========================================================================================\n");
    for(int i=0;i<n;i++)
    {
        printf("%-10d %-15d %-10d %-10d %-12d %-15d %-18d\n",
               processes[0][i],   // Process ID
               processes[1][i],   // Arrival Time
               processes[2][i],   // Burst Time
               processes[3][i],   // Start Time
               processes[4][i],   // Finish Time
               processes[5][i],   // Waiting Time
               processes[6][i]    // Turnaround Time
               );
    }
    return 0;
}
